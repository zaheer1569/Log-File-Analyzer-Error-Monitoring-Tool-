from __future__ import annotations

from contextlib import redirect_stderr, redirect_stdout
import io
from pathlib import Path
import tempfile
import unittest

from log_analyzer.cli import main


class CliTests(unittest.TestCase):
    def test_successful_run_creates_deliverables(self) -> None:
        with tempfile.TemporaryDirectory() as temp_dir:
            root = Path(temp_dir)
            log_path = root / "input.log"
            output_dir = root / "reports"
            log_path.write_text(
                "\n".join(
                    [
                        "2026-10-20 10:00:00 | INFO | api | Started",
                        "2026-10-20 10:00:01 | ERROR | database | Timeout id=1",
                        "malformed line",
                    ]
                ),
                encoding="utf-8",
            )

            stdout = io.StringIO()
            stderr = io.StringIO()
            with redirect_stdout(stdout), redirect_stderr(stderr):
                exit_code = main(
                    [
                        str(log_path),
                        "--output-dir",
                        str(output_dir),
                        "--top",
                        "3",
                    ]
                )

            self.assertEqual(exit_code, 0)
            self.assertIn("LOG FILE ANALYSIS SUMMARY", stdout.getvalue())
            self.assertTrue((output_dir / "analysis_report.txt").exists())
            self.assertTrue((output_dir / "analysis_report.csv").exists())
            self.assertTrue((output_dir / "top_errors.csv").exists())
            self.assertTrue((output_dir / "analyzer_runtime.log").exists())

    def test_strict_mode_fails_on_malformed_line(self) -> None:
        with tempfile.TemporaryDirectory() as temp_dir:
            root = Path(temp_dir)
            log_path = root / "input.log"
            log_path.write_text("bad line\n", encoding="utf-8")

            stdout = io.StringIO()
            stderr = io.StringIO()
            with redirect_stdout(stdout), redirect_stderr(stderr):
                exit_code = main(
                    [
                        str(log_path),
                        "--output-dir",
                        str(root / "reports"),
                        "--strict",
                    ]
                )

            self.assertEqual(exit_code, 3)
            self.assertIn("strict parsing failed", stderr.getvalue())


if __name__ == "__main__":
    unittest.main()
