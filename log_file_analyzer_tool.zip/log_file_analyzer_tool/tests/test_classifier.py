from __future__ import annotations

import unittest

from log_analyzer.classifier import classify_event, normalize_message


class ClassifierTests(unittest.TestCase):
    def test_database_category_has_priority_over_timeout(self) -> None:
        self.assertEqual(
            classify_event("database", "Timeout while fetching a record"),
            "DATABASE",
        )

    def test_network_category(self) -> None:
        self.assertEqual(
            classify_event("client", "Connection refused by host 10.0.0.1"),
            "NETWORK",
        )

    def test_normalize_dynamic_values(self) -> None:
        first = normalize_message(
            "Connection refused by host 10.0.0.5 port 443 request_id=12345"
        )
        second = normalize_message(
            "Connection refused by host 10.0.0.6 port 443 request_id=99999"
        )

        self.assertEqual(first, second)
        self.assertIn("<ip>", first)
        self.assertIn("<num>", first)


if __name__ == "__main__":
    unittest.main()
