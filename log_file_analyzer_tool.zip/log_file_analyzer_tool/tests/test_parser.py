from __future__ import annotations

from datetime import timezone
import unittest

from log_analyzer.models import LogEntry, ParseIssue
from log_analyzer.parser import parse_log_line


class ParseLogLineTests(unittest.TestCase):
    def test_parses_pipe_format(self) -> None:
        record = parse_log_line(
            "2026-10-20 08:01:14 | ERROR | database | Query failed id=10\n",
            7,
        )

        self.assertIsInstance(record, LogEntry)
        assert isinstance(record, LogEntry)
        self.assertEqual(record.level, "ERROR")
        self.assertEqual(record.module, "database")
        self.assertEqual(record.category, "DATABASE")
        self.assertEqual(record.line_number, 7)

    def test_parses_bracket_format(self) -> None:
        record = parse_log_line(
            "2026-10-20 08:09:15 [INFO] audit - Export requested",
            1,
        )

        self.assertIsInstance(record, LogEntry)
        assert isinstance(record, LogEntry)
        self.assertEqual(record.level, "INFO")
        self.assertEqual(record.module, "audit")
        self.assertEqual(record.message, "Export requested")

    def test_warn_is_normalized_to_warning(self) -> None:
        record = parse_log_line(
            "2026-10-20 08:09:15 | WARN | api | Slow request duration=1000ms",
            1,
        )

        self.assertIsInstance(record, LogEntry)
        assert isinstance(record, LogEntry)
        self.assertEqual(record.level, "WARNING")

    def test_z_timestamp_is_timezone_aware(self) -> None:
        record = parse_log_line(
            "2026-10-20T08:09:15Z | INFO | api | Request completed",
            1,
        )

        self.assertIsInstance(record, LogEntry)
        assert isinstance(record, LogEntry)
        self.assertEqual(record.timestamp.tzinfo, timezone.utc)

    def test_malformed_line_returns_issue(self) -> None:
        record = parse_log_line("not a valid line", 4)

        self.assertIsInstance(record, ParseIssue)
        assert isinstance(record, ParseIssue)
        self.assertIn("supported log format", record.reason)

    def test_unsupported_level_returns_issue(self) -> None:
        record = parse_log_line(
            "2026-10-20 08:09:15 | NOTICE | api | Something happened",
            1,
        )

        self.assertIsInstance(record, ParseIssue)
        assert isinstance(record, ParseIssue)
        self.assertIn("unsupported level", record.reason)


if __name__ == "__main__":
    unittest.main()
