from __future__ import annotations

import unittest

from log_analyzer.analyzer import LogAnalyzer
from log_analyzer.parser import parse_log_line


class AnalyzerTests(unittest.TestCase):
    def test_counts_and_groups_recurring_errors(self) -> None:
        lines = [
            "2026-10-20 10:00:00 | INFO | api | Started",
            "2026-10-20 10:00:01 | WARNING | api | Slow request duration=1000ms",
            "2026-10-20 10:00:02 | ERROR | database | Timeout for order_id=101",
            "2026-10-20 10:00:03 | ERROR | database | Timeout for order_id=102",
            "2026-10-20 10:00:04 | ERROR | worker | ValueError in job_id=77",
            "bad line",
        ]
        records = [parse_log_line(line, number) for number, line in enumerate(lines, 1)]

        result = LogAnalyzer().analyze(records)

        self.assertEqual(result.total_lines, 6)
        self.assertEqual(result.parsed_entries, 5)
        self.assertEqual(result.malformed_lines, 1)
        self.assertEqual(result.error_total, 3)
        self.assertEqual(result.warning_total, 1)
        self.assertEqual(result.level_counts["INFO"], 1)
        self.assertEqual(result.category_counts["DATABASE"], 2)

        signature, count = result.top_errors(1)[0]
        self.assertEqual(count, 2)
        self.assertIn("order_id=<num>", signature)

    def test_empty_input(self) -> None:
        result = LogAnalyzer().analyze([])

        self.assertEqual(result.total_lines, 0)
        self.assertEqual(result.parse_success_rate, 0.0)
        self.assertEqual(result.top_errors(), [])


if __name__ == "__main__":
    unittest.main()
