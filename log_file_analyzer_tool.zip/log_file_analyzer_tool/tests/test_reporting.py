from __future__ import annotations

import csv
from pathlib import Path
import tempfile
import unittest

from log_analyzer.analyzer import LogAnalyzer
from log_analyzer.parser import parse_log_line
from log_analyzer.reporting import (
    build_console_summary,
    write_csv_report,
    write_text_report,
    write_top_errors_csv,
)


class ReportingTests(unittest.TestCase):
    def setUp(self) -> None:
        records = [
            parse_log_line(
                "2026-10-20 10:00:00 | ERROR | database | Timeout id=1",
                1,
            ),
            parse_log_line(
                "2026-10-20 10:00:01 | ERROR | database | Timeout id=2",
                2,
            ),
            parse_log_line(
                "2026-10-20 10:00:02 | INFO | api | Completed",
                3,
            ),
        ]
        self.result = LogAnalyzer().analyze(records)

    def test_console_summary_contains_key_metrics(self) -> None:
        summary = build_console_summary(self.result, top_n=3)
        self.assertIn("LOG FILE ANALYSIS SUMMARY", summary)
        self.assertIn("Errors/Critical", summary)
        self.assertIn("2x", summary)

    def test_writes_all_reports(self) -> None:
        with tempfile.TemporaryDirectory() as temp_dir:
            root = Path(temp_dir)
            text_path = write_text_report(self.result, root / "report.txt")
            csv_path = write_csv_report(self.result, root / "report.csv")
            top_path = write_top_errors_csv(self.result, root / "top.csv")

            self.assertTrue(text_path.exists())
            self.assertTrue(csv_path.exists())
            self.assertTrue(top_path.exists())
            self.assertIn("TOP 5 RECURRING ERRORS", text_path.read_text(encoding="utf-8"))

            with top_path.open(encoding="utf-8", newline="") as handle:
                rows = list(csv.DictReader(handle))
            self.assertEqual(len(rows), 1)
            self.assertEqual(rows[0]["occurrences"], "2")


if __name__ == "__main__":
    unittest.main()
