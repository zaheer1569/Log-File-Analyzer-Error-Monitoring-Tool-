# Project Plan and Team Allocation

## Objective

Build a Python utility that reads application logs as a stream, extracts structured fields, classifies events, identifies frequent warnings/errors, and writes useful operational reports.

## Data structures

| Structure | Use |
|---|---|
| `LogEntry` dataclass | Parsed timestamp, level, module, message, category, and source line |
| `ParseIssue` dataclass | Malformed-line details without losing the rest of the file |
| `Counter` | Level, module, category, warning-signature, and error-signature counts |
| `dict[str, ErrorPatternDetail]` | Sample message plus first/last occurrence for each error signature |
| `AnalysisResult` dataclass | Shared result passed to all report writers |

## Participant 1

### Primary files

- `log_analyzer/models.py`
- `log_analyzer/parser.py`
- `log_analyzer/classifier.py`
- `tests/test_parser.py`
- `tests/test_classifier.py`

### Tasks

1. Define accepted log formats and parsing regexes.
2. Implement generator-based file reading.
3. Normalize level aliases such as `WARN`.
4. Return structured parse issues for bad lines.
5. Implement category rules.
6. Implement normalization of dynamic values.
7. Add parser and classifier tests.

## Participant 2

### Primary files

- `log_analyzer/analyzer.py`
- `log_analyzer/reporting.py`
- `log_analyzer/logging_config.py`
- `log_analyzer/cli.py`
- `tests/test_analyzer.py`
- `tests/test_reporting.py`
- `tests/test_cli.py`

### Tasks

1. Build `Counter`-based aggregation.
2. Track error and warning totals.
3. Rank recurring errors with `most_common()`.
4. Track first/last timestamps and sample messages.
5. Generate console, text, and CSV output.
6. Configure runtime logging.
7. Handle file, permission, encoding, and strict-parse failures.
8. Add analysis, report, and end-to-end CLI tests.

## Shared integration checklist

- [ ] Run all tests.
- [ ] Run the sample log.
- [ ] Verify all four output files.
- [ ] Open both CSV files in a spreadsheet application.
- [ ] Confirm malformed lines do not stop normal mode.
- [ ] Confirm `--strict` returns exit code 3.
- [ ] Confirm IDs with different values group into one error signature.
- [ ] Prepare a two-person demo handoff.

## Suggested 4–5 hour execution plan

### 0:00–0:30 — Design and task split

- Agree on supported input formats.
- Sketch dataclasses and counters.
- Assign files to each participant.
- Define two or three sample recurring errors.

### 0:30–2:30 — Core implementation

Participant 1:

- iterator reader;
- regex parser;
- classification and normalization;
- parser tests.

Participant 2:

- counters and time range;
- top-error analysis;
- output writers;
- analyzer tests.

### 2:30–3:15 — Exceptions and logging

- missing file;
- permission and encoding errors;
- malformed-line behavior;
- strict mode;
- rotating application log.

### 3:15–4:00 — Refactoring and test expansion

- remove duplicated formatting logic;
- improve names and type hints;
- test empty input and edge cases;
- verify CSV headers and rows.

### 4:00–4:45 — Integration and demo preparation

- run all tests;
- generate final reports;
- rehearse the console command;
- assign speaking sections;
- explain how each evaluation criterion is met.

## Suggested demo ownership

Participant 1 demonstrates input formats, iterator reading, regex parsing, and classification.

Participant 2 demonstrates counts, normalized recurring errors, generated files, runtime logging, and tests.
