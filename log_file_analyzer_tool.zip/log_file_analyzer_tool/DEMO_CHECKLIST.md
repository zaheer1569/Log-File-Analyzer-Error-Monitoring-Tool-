# Five-Minute Demo Checklist

## 1. Show the sample input — 30 seconds

Open `sample_logs/application.log` and point out:

- INFO, WARNING/WARN, ERROR, CRITICAL, and DEBUG entries;
- pipe and bracket formats;
- repeated database errors with different IDs;
- the intentionally malformed line.

## 2. Run the application — 30 seconds

```bash
python -m log_analyzer sample_logs/application.log --output-dir reports --top 5
```

Explain that the file is processed line-by-line through an iterator.

## 3. Explain the console summary — 60 seconds

Highlight:

- 30 physical lines;
- 29 parsed entries;
- one malformed line;
- 16 ERROR/CRITICAL events;
- five warnings;
- the top recurring-error list.

Point out that three database timeout messages become one pattern because their order IDs are normalized to `<num>`.

## 4. Show generated files — 60 seconds

Open:

- `reports/analysis_report.txt`;
- `reports/analysis_report.csv`;
- `reports/top_errors.csv`;
- `reports/analyzer_runtime.log`.

Explain the different audiences: operators, spreadsheets/scripts, and developers troubleshooting the analyzer.

## 5. Show error handling — 45 seconds

Run strict mode against the edge-case file:

```bash
python -m log_analyzer sample_logs/edge_cases.log --output-dir reports/strict --strict
```

Explain the non-zero exit code and runtime-log entry.

## 6. Run tests — 45 seconds

```bash
python -m unittest discover -s tests -v
```

Mention the parser, classifier, analyzer, reporting, and CLI coverage.

## 7. Close with evaluation mapping — 30 seconds

- Parsing: two formats and structured parse issues.
- Analysis: counters and top recurring errors.
- Data structures: dataclasses, dictionaries, counters, iterator.
- Error handling/logging: guarded CLI and rotating file log.
- Testing: fifteen tests.
- Demo: sample data, scripts, and reports.
