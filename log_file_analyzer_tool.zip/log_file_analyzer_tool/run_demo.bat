@echo off
setlocal

py -m log_analyzer sample_logs\application.log --output-dir reports --top 5
if errorlevel 1 exit /b %errorlevel%

py -m unittest discover -s tests -v
exit /b %errorlevel%
