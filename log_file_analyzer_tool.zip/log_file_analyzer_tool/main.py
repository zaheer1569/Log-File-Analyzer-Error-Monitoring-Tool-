"""Convenience entry point: ``python main.py <log-file>``."""

from log_analyzer.cli import main


if __name__ == "__main__":
    raise SystemExit(main())
