#!/usr/bin/env sh
set -eu

python3 -m log_analyzer sample_logs/application.log --output-dir reports --top 5
python3 -m unittest discover -s tests -v
