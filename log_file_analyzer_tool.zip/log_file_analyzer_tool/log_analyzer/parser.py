"""Streaming log-file reading and line parsing."""

from __future__ import annotations

from collections.abc import Iterator
from datetime import datetime
from pathlib import Path
import re

from .classifier import classify_event
from .models import LogEntry, LogRecord, ParseIssue


_TIMESTAMP = (
    r"\d{4}-\d{2}-\d{2}[ T]\d{2}:\d{2}:\d{2}"
    r"(?:[.,]\d{1,6})?(?:Z|[+-]\d{2}:?\d{2})?"
)

_PIPE_PATTERN = re.compile(
    rf"^\s*(?P<timestamp>{_TIMESTAMP})\s*\|\s*"
    r"(?P<level>[A-Za-z]+)\s*\|\s*"
    r"(?P<module>[^|]+?)\s*\|\s*"
    r"(?P<message>.+?)\s*$"
)

_BRACKET_PATTERN = re.compile(
    rf"^\s*(?P<timestamp>{_TIMESTAMP})\s+"
    r"\[(?P<level>[A-Za-z]+)\]\s+"
    r"(?P<module>[\w./-]+)\s*-\s*"
    r"(?P<message>.+?)\s*$"
)

_SUPPORTED_LEVELS = {"DEBUG", "INFO", "WARNING", "ERROR", "CRITICAL"}
_LEVEL_ALIASES = {"WARN": "WARNING", "FATAL": "CRITICAL"}


def _parse_timestamp(value: str) -> datetime:
    cleaned = value.replace(",", ".")
    if cleaned.endswith("Z"):
        cleaned = cleaned[:-1] + "+00:00"

    # Python accepts +05:30. Convert +0530 to +05:30 when necessary.
    if re.search(r"[+-]\d{4}$", cleaned):
        cleaned = f"{cleaned[:-5]}{cleaned[-5:-2]}:{cleaned[-2:]}"

    return datetime.fromisoformat(cleaned)


def parse_log_line(raw_line: str, line_number: int) -> LogRecord:
    """Parse one physical line into a :class:`LogEntry` or :class:`ParseIssue`."""

    text = raw_line.rstrip("\r\n")
    if not text.strip():
        return ParseIssue(line_number, text, "blank line")

    match = _PIPE_PATTERN.match(text) or _BRACKET_PATTERN.match(text)
    if match is None:
        return ParseIssue(
            line_number,
            text,
            "line does not match a supported log format",
        )

    level = match.group("level").upper()
    level = _LEVEL_ALIASES.get(level, level)
    if level not in _SUPPORTED_LEVELS:
        return ParseIssue(line_number, text, f"unsupported level: {level}")

    try:
        timestamp = _parse_timestamp(match.group("timestamp"))
    except ValueError as exc:
        return ParseIssue(line_number, text, f"invalid timestamp: {exc}")

    module = match.group("module").strip()
    message = match.group("message").strip()
    if not module:
        return ParseIssue(line_number, text, "module is empty")
    if not message:
        return ParseIssue(line_number, text, "message is empty")

    return LogEntry(
        timestamp=timestamp,
        level=level,
        module=module,
        message=message,
        category=classify_event(module, message),
        line_number=line_number,
        raw_line=text,
    )


def iter_log_records(
    path: str | Path,
    *,
    encoding: str = "utf-8",
) -> Iterator[LogRecord]:
    """Yield parsed records one line at a time without loading the whole file."""

    log_path = Path(path)
    with log_path.open("r", encoding=encoding) as handle:
        for line_number, raw_line in enumerate(handle, start=1):
            yield parse_log_line(raw_line, line_number)
