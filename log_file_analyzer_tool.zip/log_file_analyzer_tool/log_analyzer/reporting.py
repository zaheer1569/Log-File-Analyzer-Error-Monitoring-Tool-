"""Console, text, and CSV report generation."""

from __future__ import annotations

import csv
from datetime import datetime
from pathlib import Path
from textwrap import shorten

from .analyzer import AnalysisResult


def _format_timestamp(value: datetime | None) -> str:
    return value.isoformat(sep=" ") if value else "N/A"


def _percentage(count: int, total: int) -> str:
    if total == 0:
        return "0.00"
    return f"{(count / total) * 100:.2f}"


def build_console_summary(result: AnalysisResult, *, top_n: int = 5) -> str:
    """Build a compact operational summary suitable for terminal output."""

    lines = [
        "=" * 72,
        "LOG FILE ANALYSIS SUMMARY",
        "=" * 72,
        f"Physical lines        : {result.total_lines}",
        f"Parsed entries        : {result.parsed_entries}",
        f"Malformed lines       : {result.malformed_lines}",
        f"Parse success rate    : {result.parse_success_rate:.2f}%",
        f"Errors/Critical       : {result.error_total}",
        f"Warnings              : {result.warning_total}",
        f"Time range            : {_format_timestamp(result.first_timestamp)}",
        f"                      -> {_format_timestamp(result.last_timestamp)}",
        "",
        "Counts by level",
        "-" * 72,
    ]

    if result.level_counts:
        for level, count in result.level_counts.most_common():
            lines.append(f"{level:<18} {count:>8}")
    else:
        lines.append("No parsed entries.")

    lines.extend(["", f"Top {top_n} recurring errors", "-" * 72])
    top_errors = result.top_errors(top_n)
    if not top_errors:
        lines.append("No ERROR or CRITICAL entries found.")
    else:
        for rank, (signature, count) in enumerate(top_errors, start=1):
            lines.append(
                f"{rank:>2}. {count:>4}x  {shorten(signature, width=61, placeholder='...')}"
            )

    lines.append("=" * 72)
    return "\n".join(lines)


def write_text_report(
    result: AnalysisResult,
    output_path: str | Path,
    *,
    top_n: int = 5,
) -> Path:
    """Write a detailed human-readable report."""

    path = Path(output_path)
    path.parent.mkdir(parents=True, exist_ok=True)

    lines = [
        "LOG FILE ANALYSIS REPORT",
        "=" * 88,
        "",
        "OVERVIEW",
        "-" * 88,
        f"Physical lines: {result.total_lines}",
        f"Parsed entries: {result.parsed_entries}",
        f"Malformed lines: {result.malformed_lines}",
        f"Parse success rate: {result.parse_success_rate:.2f}%",
        f"Errors/Critical: {result.error_total}",
        f"Warnings: {result.warning_total}",
        f"First timestamp: {_format_timestamp(result.first_timestamp)}",
        f"Last timestamp: {_format_timestamp(result.last_timestamp)}",
        "",
        "COUNTS BY LEVEL",
        "-" * 88,
    ]

    for level, count in result.level_counts.most_common():
        lines.append(
            f"{level:<24} {count:>8} ({_percentage(count, result.parsed_entries)}%)"
        )

    lines.extend(["", "COUNTS BY CATEGORY", "-" * 88])
    for category, count in result.category_counts.most_common():
        lines.append(
            f"{category:<24} {count:>8} ({_percentage(count, result.parsed_entries)}%)"
        )

    lines.extend(["", "COUNTS BY MODULE", "-" * 88])
    for module, count in result.module_counts.most_common():
        lines.append(
            f"{module:<24} {count:>8} ({_percentage(count, result.parsed_entries)}%)"
        )

    lines.extend(["", f"TOP {top_n} RECURRING ERRORS", "-" * 88])
    top_errors = result.top_errors(top_n)
    if not top_errors:
        lines.append("No ERROR or CRITICAL entries found.")
    else:
        for rank, (signature, count) in enumerate(top_errors, start=1):
            detail = result.error_details[signature]
            lines.extend(
                [
                    f"{rank}. Occurrences: {count}",
                    f"   Module: {detail.module}",
                    f"   Category: {detail.category}",
                    f"   Pattern: {detail.normalized_message}",
                    f"   Sample: {detail.sample_message}",
                    f"   First seen: {_format_timestamp(detail.first_seen)}",
                    f"   Last seen: {_format_timestamp(detail.last_seen)}",
                    "",
                ]
            )

    lines.extend(["PARSE ISSUES", "-" * 88])
    if not result.parse_issues:
        lines.append("None.")
    else:
        for issue in result.parse_issues:
            lines.append(
                f"Line {issue.line_number}: {issue.reason} | {issue.raw_line!r}"
            )
        if result.malformed_lines > len(result.parse_issues):
            lines.append(
                f"... {result.malformed_lines - len(result.parse_issues)} additional "
                "issues were not retained in memory."
            )

    path.write_text("\n".join(lines).rstrip() + "\n", encoding="utf-8")
    return path


def write_csv_report(result: AnalysisResult, output_path: str | Path) -> Path:
    """Write summary metrics as a machine-readable CSV file."""

    path = Path(output_path)
    path.parent.mkdir(parents=True, exist_ok=True)

    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.writer(handle)
        writer.writerow(["section", "name", "value", "percentage_of_parsed"])
        writer.writerow(["overview", "physical_lines", result.total_lines, ""])
        writer.writerow(["overview", "parsed_entries", result.parsed_entries, ""])
        writer.writerow(["overview", "malformed_lines", result.malformed_lines, ""])
        writer.writerow(
            ["overview", "parse_success_rate", f"{result.parse_success_rate:.2f}", ""]
        )
        writer.writerow(["overview", "errors_critical", result.error_total, ""])
        writer.writerow(["overview", "warnings", result.warning_total, ""])
        writer.writerow(
            ["overview", "first_timestamp", _format_timestamp(result.first_timestamp), ""]
        )
        writer.writerow(
            ["overview", "last_timestamp", _format_timestamp(result.last_timestamp), ""]
        )

        for section, counter in (
            ("level", result.level_counts),
            ("category", result.category_counts),
            ("module", result.module_counts),
        ):
            for name, count in counter.most_common():
                writer.writerow(
                    [
                        section,
                        name,
                        count,
                        _percentage(count, result.parsed_entries),
                    ]
                )

    return path


def write_top_errors_csv(
    result: AnalysisResult,
    output_path: str | Path,
    *,
    top_n: int = 5,
) -> Path:
    """Write a dedicated ranked top-error list."""

    path = Path(output_path)
    path.parent.mkdir(parents=True, exist_ok=True)

    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.writer(handle)
        writer.writerow(
            [
                "rank",
                "occurrences",
                "module",
                "category",
                "normalized_message",
                "sample_message",
                "first_seen",
                "last_seen",
            ]
        )
        for rank, (signature, count) in enumerate(result.top_errors(top_n), start=1):
            detail = result.error_details[signature]
            writer.writerow(
                [
                    rank,
                    count,
                    detail.module,
                    detail.category,
                    detail.normalized_message,
                    detail.sample_message,
                    _format_timestamp(detail.first_seen),
                    _format_timestamp(detail.last_seen),
                ]
            )

    return path
