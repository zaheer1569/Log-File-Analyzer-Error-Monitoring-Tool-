"""Counter-based aggregation for parsed log records."""

from __future__ import annotations

from collections import Counter
from collections.abc import Iterable
from dataclasses import dataclass, field
from datetime import datetime, timezone

from .classifier import normalize_message
from .models import ErrorPatternDetail, LogEntry, LogRecord, ParseIssue


def _time_key(value: datetime) -> float:
    """Return a comparable timestamp for both naive and timezone-aware values."""

    if value.tzinfo is None:
        value = value.replace(tzinfo=timezone.utc)
    return value.timestamp()


@dataclass(slots=True)
class AnalysisResult:
    """Complete aggregated state used by all report writers."""

    total_lines: int = 0
    parsed_entries: int = 0
    malformed_lines: int = 0
    level_counts: Counter[str] = field(default_factory=Counter)
    module_counts: Counter[str] = field(default_factory=Counter)
    category_counts: Counter[str] = field(default_factory=Counter)
    error_counts: Counter[str] = field(default_factory=Counter)
    warning_counts: Counter[str] = field(default_factory=Counter)
    error_details: dict[str, ErrorPatternDetail] = field(default_factory=dict)
    parse_issues: list[ParseIssue] = field(default_factory=list)
    first_timestamp: datetime | None = None
    last_timestamp: datetime | None = None

    @property
    def error_total(self) -> int:
        return self.level_counts["ERROR"] + self.level_counts["CRITICAL"]

    @property
    def warning_total(self) -> int:
        return self.level_counts["WARNING"]

    @property
    def parse_success_rate(self) -> float:
        if self.total_lines == 0:
            return 0.0
        return (self.parsed_entries / self.total_lines) * 100

    def top_errors(self, limit: int = 5) -> list[tuple[str, int]]:
        return self.error_counts.most_common(limit)


class LogAnalyzer:
    """Incrementally analyze a stream of parsed records."""

    def __init__(self, *, max_saved_parse_issues: int = 50) -> None:
        self.result = AnalysisResult()
        self.max_saved_parse_issues = max_saved_parse_issues

    def process(self, record: LogRecord) -> None:
        result = self.result
        result.total_lines += 1

        if isinstance(record, ParseIssue):
            result.malformed_lines += 1
            if len(result.parse_issues) < self.max_saved_parse_issues:
                result.parse_issues.append(record)
            return

        result.parsed_entries += 1
        result.level_counts[record.level] += 1
        result.module_counts[record.module] += 1
        result.category_counts[record.category] += 1
        self._update_time_range(record.timestamp)

        normalized_message = normalize_message(record.message)
        signature = f"{record.module} | {normalized_message}"

        if record.level in {"ERROR", "CRITICAL"}:
            result.error_counts[signature] += 1
            self._update_error_detail(record, signature, normalized_message)
        elif record.level == "WARNING":
            result.warning_counts[signature] += 1

    def analyze(self, records: Iterable[LogRecord]) -> AnalysisResult:
        for record in records:
            self.process(record)
        return self.result

    def _update_time_range(self, timestamp: datetime) -> None:
        result = self.result
        if (
            result.first_timestamp is None
            or _time_key(timestamp) < _time_key(result.first_timestamp)
        ):
            result.first_timestamp = timestamp
        if (
            result.last_timestamp is None
            or _time_key(timestamp) > _time_key(result.last_timestamp)
        ):
            result.last_timestamp = timestamp

    def _update_error_detail(
        self,
        entry: LogEntry,
        signature: str,
        normalized_message: str,
    ) -> None:
        details = self.result.error_details
        existing = details.get(signature)
        if existing is None:
            details[signature] = ErrorPatternDetail(
                signature=signature,
                module=entry.module,
                category=entry.category,
                normalized_message=normalized_message,
                sample_message=entry.message,
                first_seen=entry.timestamp,
                last_seen=entry.timestamp,
            )
            return

        if _time_key(entry.timestamp) < _time_key(existing.first_seen):
            existing.first_seen = entry.timestamp
        if _time_key(entry.timestamp) > _time_key(existing.last_seen):
            existing.last_seen = entry.timestamp
