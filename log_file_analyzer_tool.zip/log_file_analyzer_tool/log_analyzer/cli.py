"""Command-line interface for the log analyzer."""

from __future__ import annotations

import argparse
import logging
from pathlib import Path
import sys

from .analyzer import LogAnalyzer
from .exceptions import LogParseError
from .models import ParseIssue
from .parser import iter_log_records
from .reporting import (
    build_console_summary,
    write_csv_report,
    write_text_report,
    write_top_errors_csv,
)
from .logging_config import configure_logging


def build_argument_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="log-analyzer",
        description=(
            "Stream an application log, classify events, count warnings/errors, "
            "and produce operational reports."
        ),
    )
    parser.add_argument("log_file", help="Path to the input .log file")
    parser.add_argument(
        "-o",
        "--output-dir",
        default="reports",
        help="Directory for generated reports (default: reports)",
    )
    parser.add_argument(
        "--top",
        type=int,
        default=5,
        help="Number of recurring errors to include (default: 5)",
    )
    parser.add_argument(
        "--encoding",
        default="utf-8",
        help="Input-file encoding (default: utf-8)",
    )
    parser.add_argument(
        "--strict",
        action="store_true",
        help="Stop with a non-zero exit code when a malformed line is found",
    )
    parser.add_argument(
        "--verbose",
        action="store_true",
        help="Show detailed runtime logging on the console",
    )
    return parser


def main(argv: list[str] | None = None) -> int:
    args = build_argument_parser().parse_args(argv)

    if args.top < 1:
        print("error: --top must be at least 1", file=sys.stderr)
        return 2

    output_dir = Path(args.output_dir)
    try:
        output_dir.mkdir(parents=True, exist_ok=True)
    except OSError as exc:
        print(f"error: cannot create output directory: {exc}", file=sys.stderr)
        return 2

    logger = configure_logging(
        output_dir / "analyzer_runtime.log",
        verbose=args.verbose,
    )
    logger.info("Analysis started for %s", args.log_file)

    analyzer = LogAnalyzer()

    try:
        for record in iter_log_records(args.log_file, encoding=args.encoding):
            if isinstance(record, ParseIssue):
                logger.warning(
                    "Malformed line %s: %s | %r",
                    record.line_number,
                    record.reason,
                    record.raw_line,
                )
                if args.strict:
                    raise LogParseError(
                        f"line {record.line_number}: {record.reason}"
                    )
            analyzer.process(record)

        result = analyzer.result
        text_path = write_text_report(
            result,
            output_dir / "analysis_report.txt",
            top_n=args.top,
        )
        csv_path = write_csv_report(result, output_dir / "analysis_report.csv")
        top_path = write_top_errors_csv(
            result,
            output_dir / "top_errors.csv",
            top_n=args.top,
        )

        print(build_console_summary(result, top_n=args.top))
        print(f"Text report           : {text_path}")
        print(f"CSV report            : {csv_path}")
        print(f"Top errors CSV        : {top_path}")
        print(f"Application log       : {output_dir / 'analyzer_runtime.log'}")

        logger.info(
            "Analysis completed: lines=%s parsed=%s malformed=%s errors=%s warnings=%s",
            result.total_lines,
            result.parsed_entries,
            result.malformed_lines,
            result.error_total,
            result.warning_total,
        )
        return 0

    except FileNotFoundError:
        logger.exception("Input file does not exist: %s", args.log_file)
        print(f"error: input file not found: {args.log_file}", file=sys.stderr)
        return 2
    except PermissionError:
        logger.exception("Permission denied while reading: %s", args.log_file)
        print(f"error: permission denied: {args.log_file}", file=sys.stderr)
        return 2
    except UnicodeDecodeError as exc:
        logger.exception("Cannot decode input file")
        print(
            f"error: cannot decode input with encoding {args.encoding}: {exc}",
            file=sys.stderr,
        )
        return 2
    except LogParseError as exc:
        logger.error("Strict parsing failed: %s", exc)
        print(f"error: strict parsing failed: {exc}", file=sys.stderr)
        return 3
    except OSError as exc:
        logger.exception("File-system error")
        print(f"error: file-system operation failed: {exc}", file=sys.stderr)
        return 2
    except Exception:
        logger.exception("Unexpected analyzer failure")
        print("error: unexpected analyzer failure; see application log", file=sys.stderr)
        return 1
    finally:
        # Explicitly close the rotating file handler so repeated in-process
        # calls and Windows test cleanup do not retain an open report file.
        for handler in logger.handlers[:]:
            try:
                handler.flush()
            finally:
                handler.close()
                logger.removeHandler(handler)


if __name__ == "__main__":
    raise SystemExit(main())
