"""Data models used by the log analyzer."""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
from typing import TypeAlias


@dataclass(frozen=True, slots=True)
class LogEntry:
    """A successfully parsed application-log entry."""

    timestamp: datetime
    level: str
    module: str
    message: str
    category: str
    line_number: int
    raw_line: str


@dataclass(frozen=True, slots=True)
class ParseIssue:
    """Represents a physical log line that could not be parsed."""

    line_number: int
    raw_line: str
    reason: str


LogRecord: TypeAlias = LogEntry | ParseIssue


@dataclass(slots=True)
class ErrorPatternDetail:
    """Additional information retained for a recurring error signature."""

    signature: str
    module: str
    category: str
    normalized_message: str
    sample_message: str
    first_seen: datetime
    last_seen: datetime
