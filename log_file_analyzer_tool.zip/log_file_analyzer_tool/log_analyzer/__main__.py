"""Allow execution with ``python -m log_analyzer``."""

from .cli import main

raise SystemExit(main())
