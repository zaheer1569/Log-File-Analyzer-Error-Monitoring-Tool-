"""Custom exceptions for the project."""


class LogAnalyzerError(Exception):
    """Base exception for expected analyzer failures."""


class LogParseError(LogAnalyzerError):
    """Raised when strict parsing encounters an invalid log line."""
