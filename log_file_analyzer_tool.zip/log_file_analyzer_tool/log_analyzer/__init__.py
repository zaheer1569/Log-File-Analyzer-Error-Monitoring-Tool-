"""Log File Analyzer & Error Monitoring Tool."""

from .analyzer import AnalysisResult, LogAnalyzer
from .parser import iter_log_records, parse_log_line

__all__ = [
    "AnalysisResult",
    "LogAnalyzer",
    "iter_log_records",
    "parse_log_line",
]

__version__ = "1.0.0"
