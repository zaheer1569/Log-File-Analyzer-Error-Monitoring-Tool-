"""Rule-based event classification and message normalization."""

from __future__ import annotations

import re


_CATEGORY_RULES: tuple[tuple[str, re.Pattern[str]], ...] = (
    (
        "DATABASE",
        re.compile(
            r"\b(database|db|sql|query|postgres(?:ql)?|mysql|oracle|deadlock|"
            r"connection\s+pool)\b",
            re.IGNORECASE,
        ),
    ),
    (
        "AUTHENTICATION",
        re.compile(
            r"\b(auth(?:entication|orization)?|login|logout|token|credential|"
            r"password|unauthori[sz]ed|forbidden|permission)\b",
            re.IGNORECASE,
        ),
    ),
    (
        "FILE_SYSTEM",
        re.compile(
            r"\b(file|filesystem|disk|directory|path|storage|no\s+space|"
            r"i/o|ioerror|read|write)\b",
            re.IGNORECASE,
        ),
    ),
    (
        "NETWORK",
        re.compile(
            r"\b(network|socket|dns|host|port|http|https|gateway|connection|"
            r"refused|unreachable|timeout)\b",
            re.IGNORECASE,
        ),
    ),
    (
        "VALIDATION",
        re.compile(
            r"\b(validation|validate|invalid|malformed|missing|required|"
            r"schema|format|constraint)\b",
            re.IGNORECASE,
        ),
    ),
    (
        "PERFORMANCE",
        re.compile(
            r"\b(slow|latency|duration|performance|memory|cpu|load|throughput)\b",
            re.IGNORECASE,
        ),
    ),
)

_UUID_RE = re.compile(
    r"\b[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}\b",
    re.IGNORECASE,
)
_IPV4_RE = re.compile(r"\b(?:\d{1,3}\.){3}\d{1,3}\b")
_HEX_RE = re.compile(r"\b0x[0-9a-f]+\b", re.IGNORECASE)
_LONG_HEX_TOKEN_RE = re.compile(r"\b[0-9a-f]{16,}\b", re.IGNORECASE)
_NUMBER_RE = re.compile(r"(?<![A-Za-z])\d+(?:\.\d+)?")
_WHITESPACE_RE = re.compile(r"\s+")


def classify_event(module: str, message: str) -> str:
    """Return a broad operational category for an event.

    The module is intentionally checked together with the message so a module
    such as ``database`` wins over a generic word such as ``timeout``.
    """

    searchable_text = f"{module} {message}"
    for category, pattern in _CATEGORY_RULES:
        if pattern.search(searchable_text):
            return category
    return "GENERAL"


def normalize_message(message: str) -> str:
    """Normalize volatile values so repeated errors group together.

    IDs, IP addresses, UUIDs, long hexadecimal tokens, and standalone numbers
    are replaced with stable placeholders. The descriptive text remains intact.
    """

    normalized = _UUID_RE.sub("<uuid>", message)
    normalized = _IPV4_RE.sub("<ip>", normalized)
    normalized = _HEX_RE.sub("<hex>", normalized)
    normalized = _LONG_HEX_TOKEN_RE.sub("<hex-token>", normalized)
    normalized = _NUMBER_RE.sub("<num>", normalized)
    normalized = _WHITESPACE_RE.sub(" ", normalized).strip()
    return normalized
